<?php $__env->startSection('title', 'CATEGORIAS'); ?>
<?php $__env->startSection('name-section', 'CATEGORIAS'); ?>

<?php $__env->startSection('description', 'actualizar registro de categoria'); ?>
<?php $__env->startSection('item-breadcrumb', 'actualizar'); ?>
<?php $__env->startSection('section-breadcrumb', 'Categorías'); ?>
<?php $__env->startSection('module-breadcrumb', 'Configuraciones'); ?>


<?php $__env->startSection('content'); ?>
<div class="card bg-white border-0 shadow-sm border-5 border-top border-secondary">
                <div class="card-body">
                    <form action="<?php echo e(route('categories.update', $category->id)); ?>" method="POS1">
                    
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    <?php echo $__env->make('settings.categories._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </form>
                </div>
            </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.administrador', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Proyecto_Farmacia\sistema\resources\views\settings\categories\roles\edit.blade.php ENDPATH**/ ?>