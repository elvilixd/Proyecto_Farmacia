

<?php $__env->startSection('title', 'USUARIOS'); ?>
<?php $__env->startSection('name-section', 'USUARIOS'); ?>
<?php $__env->startSection('description', 'Listado de usuarios'); ?>
<?php $__env->startSection('item-breadcrumb', 'Inicio'); ?>
<?php $__env->startSection('section-breadcrumb', 'Usuarios'); ?>
<?php $__env->startSection('module-breadcrumb', 'Configuraciones'); ?>

<?php $__env->startSection('content'); ?>
<div class="card bg-white border-0 shadow-sm border-5 border-top border-secondary">
    <div class="card-header bg-white">
        <div class="row">
            <div class="col-12 col-md-3">
                <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary rounded-3 text-uppercase text-white w-100">
                    <i class="bi bi-plus-lg me-2"></i>
                    <span class="small fw-medium">Nuevo usuario</span>
                </a>
            </div>
        </div>
    </div>

    <div class="card-body">
        <?php if(session('success')): ?>
            <div class="alert alert-success small" role="alert"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <h6 class="text-uppercase small text-muted mb-3">
            Total de registros encontrados: <?php echo e($users->count()); ?>

        </h6>

        <div class="table-responsive">
            <table class="table table-sm table-hover w-100 bg-white">
                <thead>
                    <tr>
                        <th class="text-center align-middle text-uppercase small">Nº</th>
                        <th class="text-center align-middle text-uppercase small">Nombre</th>
                        <th class="text-center align-middle text-uppercase small">DNI</th>
                        <th class="text-center align-middle text-uppercase small">Teléfono</th>
                        <th class="text-center align-middle text-uppercase small">Correo</th>
                        <th class="text-center align-middle text-uppercase small">Rol</th>
                        <th class="text-center align-middle text-uppercase small">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="text-center align-middle"><?php echo e($index + 1); ?></td>
                            <td class="text-start align-middle"><?php echo e($user->name); ?></td>
                            <td class="text-center align-middle"><?php echo e($user->dni); ?></td>
                            <td class="text-center align-middle"><?php echo e($user->phone); ?></td>
                            <td class="text-start align-middle"><?php echo e($user->email); ?></td>
                            <td class="text-center align-middle"><?php echo e($user->role?->name ?? 'Sin rol'); ?></td>
                            <td class="text-center align-middle">
                                <div class="dropdown">
                                    <button class="btn btn-light" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                        <i class="bi bi-three-dots-vertical"></i>
                                    </button>
                                    <ul class="dropdown-menu dropdown-menu-end">
                                        <li>
                                            <a class="dropdown-item" href="<?php echo e(route('users.edit', $user)); ?>">Editar</a>
                                        </li>
                                        <li>
                                            <form action="<?php echo e(route('users.destroy', $user)); ?>" method="POST" onsubmit="return confirm('¿Eliminar este usuario?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="dropdown-item">Eliminar</button>
                                            </form>
                                        </li>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center text-secondary py-4">No hay usuarios registrados.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.administrador', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Proyecto_Farmacia\sistema\resources\views\users\index.blade.php ENDPATH**/ ?>