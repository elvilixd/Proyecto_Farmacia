

<?php $__env->startSection('title', 'VENTAS'); ?>
<?php $__env->startSection('name-section', 'VENTAS'); ?>
<?php $__env->startSection('description', 'Registrar venta'); ?>
<?php $__env->startSection('item-breadcrumb', 'Inicio'); ?>
<?php $__env->startSection('section-breadcrumb', 'Ventas'); ?>
<?php $__env->startSection('module-breadcrumb', 'Gestión'); ?>

<?php $__env->startSection('content'); ?>
<div class="card bg-white border-0 shadow-sm border-5 border-top border-secondary">
    <div class="card-body">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger small">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('sales.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label small fw-semibold">Cliente</label>
                    <select name="customer_id" class="form-select" required>
                        <option value="">Selecciona un cliente</option>
                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($customer->id); ?>" <?php if(old('customer_id') == $customer->id): echo 'selected'; endif; ?>>
                                <?php echo e($customer->nombre); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="col-md-6">
                    <label class="form-label small fw-semibold">Vendedor</label>
                    <input type="text" class="form-control" value="<?php echo e(auth()->user()->name); ?>" disabled>
                </div>

                <div class="col-md-8">
                    <label class="form-label small fw-semibold">Medicamento</label>
                    <select name="medicine_id" class="form-select" required>
                        <option value="">Selecciona un medicamento</option>
                        <?php $__currentLoopData = $medicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($medicine->id); ?>" <?php if(old('medicine_id') == $medicine->id): echo 'selected'; endif; ?>>
                                <?php echo e($medicine->name); ?> - S/ <?php echo e(number_format($medicine->price, 2)); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="col-md-4">
                    <label class="form-label small fw-semibold">Cantidad</label>
                    <input type="number" name="amount" value="<?php echo e(old('amount', 1)); ?>" class="form-control" min="1" required>
                </div>
            </div>

            <div class="d-flex gap-2 mt-4">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-check-lg me-1"></i>Registrar venta
                </button>
                <a href="<?php echo e(route('sales.index')); ?>" class="btn btn-secondary">Volver</a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.administrador', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Proyecto_Farmacia\sistema\resources\views\management\sales\create.blade.php ENDPATH**/ ?>