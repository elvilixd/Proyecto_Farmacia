

<?php $__env->startSection('title', 'ROLES'); ?>
<?php $__env->startSection('name-section', 'ROLES'); ?>
<?php $__env->startSection('description', 'Listado de roles'); ?>
<?php $__env->startSection('item-breadcrumb', 'Inicio'); ?>
<?php $__env->startSection('section-breadcrumb', 'Roles'); ?>
<?php $__env->startSection('module-breadcrumb', 'Configuraciones'); ?>

<?php $__env->startSection('content'); ?>
<div class="card bg-white border-0 shadow-sm border-5 border-top border-secondary">
    <div class="card-header bg-white">
        <div class="row">
            <div class="col-12 col-md-3">
                <a href="<?php echo e(route('roles.create')); ?>" class="btn btn-primary rounded-3 text-uppercase text-white w-100">
                    <i class="bi bi-plus-lg me-2"></i>
                    <span class="small fw-medium">Nuevo rol</span>
                </a>
            </div>
        </div>
    </div>

    <div class="card-body">
        <?php if(session('ok')): ?>
            <div class="alert alert-success small" role="alert"><?php echo e(session('ok')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger small" role="alert"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <h6 class="text-uppercase small text-muted mb-3">
            Total de registros encontrados: <?php echo e($roles->count()); ?>

        </h6>

        <div class="table-responsive">
            <table class="table table-sm table-hover w-100 bg-white">
                <thead>
                    <tr>
                        <th class="text-center align-middle text-uppercase small">Nº</th>
                        <th class="text-center align-middle text-uppercase small">Nombre</th>
                        <th class="text-center align-middle text-uppercase small">Descripción</th>
                        <th class="text-center align-middle text-uppercase small">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="text-center align-middle"><?php echo e($index + 1); ?></td>
                            <td class="text-start align-middle"><?php echo e($role->name); ?></td>
                            <td class="text-start align-middle"><?php echo e($role->description ?? '-'); ?></td>
                            <td class="text-center align-middle">
                                <div class="dropdown">
                                    <button class="btn btn-light" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                        <i class="bi bi-three-dots-vertical"></i>
                                    </button>
                                    <ul class="dropdown-menu dropdown-menu-end">
                                        <li>
                                            <a class="dropdown-item" href="<?php echo e(route('roles.edit', $role)); ?>">Editar</a>
                                        </li>
                                        <li>
                                            <form action="<?php echo e(route('roles.destroy', $role)); ?>" method="POST" onsubmit="return confirm('¿Eliminar este rol?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="dropdown-item">Eliminar</button>
                                            </form>
                                        </li>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="text-center text-secondary py-4">No hay roles registrados.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.administrador', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Proyecto_Farmacia\sistema\resources\views\settings\roles\index.blade.php ENDPATH**/ ?>