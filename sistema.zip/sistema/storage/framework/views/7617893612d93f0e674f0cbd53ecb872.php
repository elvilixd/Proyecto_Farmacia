

<?php $__env->startSection('title', 'VENTAS'); ?>
<?php $__env->startSection('name-section', 'VENTAS'); ?>
<?php $__env->startSection('description', 'Gestión de ventas'); ?>
<?php $__env->startSection('item-breadcrumb', 'Inicio'); ?>
<?php $__env->startSection('section-breadcrumb', 'Ventas'); ?>
<?php $__env->startSection('module-breadcrumb', 'Gestión'); ?>

<?php $__env->startSection('content'); ?>
<div class="card bg-white border-0 shadow-sm border-5 border-top border-secondary">
    <div class="card-header bg-white">
        <div class="row">
            <div class="col-12 col-md-3">
                <a href="<?php echo e(route('sales.create')); ?>" class="btn btn-primary rounded-3 text-uppercase text-white w-100">
                    <i class="bi bi-plus-lg me-2"></i>
                    <span class="small fw-medium">Nueva venta</span>
                </a>
            </div>
        </div>
    </div>

    <div class="card-body">
        <?php if(session('ok')): ?>
            <div class="alert alert-success small" role="alert"><?php echo e(session('ok')); ?></div>
        <?php endif; ?>

        <div class="table-responsive">
            <table class="table table-sm table-hover w-100 bg-white">
                <thead>
                    <tr>
                        <th class="text-center align-middle text-uppercase small">Nº</th>
                        <th class="text-center align-middle text-uppercase small">Cliente</th>
                        <th class="text-center align-middle text-uppercase small">Vendedor</th>
                        <th class="text-center align-middle text-uppercase small">Total</th>
                        <th class="text-center align-middle text-uppercase small">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="text-center align-middle"><?php echo e($sale->id); ?></td>
                            <td class="text-start align-middle"><?php echo e($sale->customer_name ?? '-'); ?></td>
                            <td class="text-start align-middle"><?php echo e($sale->user_name ?? '-'); ?></td>
                            <td class="text-center align-middle">S/ <?php echo e(number_format($sale->total, 2)); ?></td>
                            <td class="text-center align-middle">
                                <?php if(auth()->user()->hasRole('Administrador')): ?>
                                    <form action="<?php echo e(route('sales.destroy', $sale->id)); ?>" method="POST" onsubmit="return confirm('¿Anular esta venta?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger">Anular</button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center text-secondary py-4">No hay ventas registradas.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.administrador', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Proyecto_Farmacia\sistema\resources\views\management\sales\index.blade.php ENDPATH**/ ?>