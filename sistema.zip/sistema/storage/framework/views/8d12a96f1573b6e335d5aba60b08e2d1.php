

<?php $__env->startSection('title', 'REPORTES'); ?>
<?php $__env->startSection('name-section', 'REPORTES'); ?>
<?php $__env->startSection('description', 'Reportes y estadísticas del sistema'); ?>
<?php $__env->startSection('item-breadcrumb', 'Inicio'); ?>
<?php $__env->startSection('section-breadcrumb', 'Reportes'); ?>
<?php $__env->startSection('module-breadcrumb', 'Principal'); ?>

<?php $__env->startSection('content'); ?>
<div class="row g-4">
    <div class="col-12 col-xl-4">
        <div class="card bg-white border-0 shadow-sm border-5 border-top border-secondary h-100">
            <div class="card-header bg-white"><h6 class="mb-0">Ventas por categoría</h6></div>
            <div class="card-body"><canvas id="categoryChart"></canvas></div>
        </div>
    </div>

    <div class="col-12 col-xl-8">
        <div class="card bg-white border-0 shadow-sm border-5 border-top border-secondary h-100">
            <div class="card-header bg-white"><h6 class="mb-0">Ventas de los últimos 7 días</h6></div>
            <div class="card-body"><canvas id="dailyChart"></canvas></div>
        </div>
    </div>

    <div class="col-12">
        <div class="card bg-white border-0 shadow-sm border-5 border-top border-secondary">
            <div class="card-header bg-white"><h6 class="mb-0">Medicamentos más vendidos</h6></div>
            <div class="card-body"><canvas id="medicineChart"></canvas></div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/chart.umd.min.js')); ?>"></script>
<script>
    // Los datos se convierten con Blade, sin usar servicios externos.
    const categoryLabels = <?php echo json_encode($salesByCategory->pluck('name'), 15, 512) ?>;
    const categoryData = <?php echo json_encode($salesByCategory->pluck('total')->map(fn ($value) => (float) $value), 15, 512) ?>;
    const dailyLabels = <?php echo json_encode($dailySales->pluck('label'), 15, 512) ?>;
    const dailyData = <?php echo json_encode($dailySales->pluck('total')->map(fn ($value) => (float) $value), 15, 512) ?>;
    const medicineLabels = <?php echo json_encode($topMedicines->pluck('name'), 15, 512) ?>;
    const medicineData = <?php echo json_encode($topMedicines->pluck('amount')->map(fn ($value) => (int) $value), 15, 512) ?>;

    new Chart(document.getElementById('categoryChart'), {
        type: 'doughnut',
        data: {
            labels: categoryLabels,
            datasets: [{
                data: categoryData,
                backgroundColor: ['#0d6efd', '#198754', '#ffc107', '#dc3545', '#6f42c1', '#20c997']
            }]
        },
        options: { responsive: true, maintainAspectRatio: true }
    });

    new Chart(document.getElementById('dailyChart'), {
        type: 'line',
        data: {
            labels: dailyLabels,
            datasets: [{
                label: 'Ventas (S/)',

<?php echo $__env->make('template.administrador', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Proyecto_Farmacia\sistema\resources\views/principal/reports/index.blade.php ENDPATH**/ ?>