<?php $__env->startSection('title', 'DASHBOARD'); ?>
<?php $__env->startSection('name-section', 'DASHBOARD'); ?>

<?php $__env->startSection('description', 'Graficos y KPIs'); ?>
<?php $__env->startSection('item-breadcrumb', 'Inicio'); ?>
<?php $__env->startSection('section-breadcrumb', 'Dashboard'); ?>
<?php $__env->startSection('module-breadcrumb', 'Principal'); ?>


<?php $__env->startSection('content'); ?>
<p>Contenido del dashboard<p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.administrador', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Proyecto_Farmacia\sistema\resources\views/principal/dashboard/index.blade.php ENDPATH**/ ?>