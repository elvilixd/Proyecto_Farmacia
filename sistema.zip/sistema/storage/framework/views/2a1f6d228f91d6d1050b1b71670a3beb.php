

<?php $__env->startSection('title', 'MEDICAMENTOS'); ?>
<?php $__env->startSection('name-section', 'MEDICAMENTOS'); ?>
<?php $__env->startSection('description', 'Gestión de medicamentos'); ?>
<?php $__env->startSection('item-breadcrumb', 'Inicio'); ?>
<?php $__env->startSection('section-breadcrumb', 'Medicamentos'); ?>
<?php $__env->startSection('module-breadcrumb', 'Gestión'); ?>

<?php $__env->startSection('content'); ?>
<div class="card bg-white border-0 shadow-sm border-5 border-top border-secondary">
    <div class="card-body text-center py-5">
        <i class="bi bi-box-seam fs-1 text-secondary d-block mb-3"></i>
        <h5 class="mb-2">Módulo de medicamentos</h5>
        <p class="text-secondary mb-0">Esta sección está disponible y se encuentra lista para su implementación.</p>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.administrador', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Proyecto_Farmacia\sistema\resources\views\management\medicines\index.blade.php ENDPATH**/ ?>