

<?php $__env->startSection('title', 'ROLES'); ?>
<?php $__env->startSection('name-section', 'ROLES'); ?>
<?php $__env->startSection('description', 'Registrar nuevo rol'); ?>
<?php $__env->startSection('item-breadcrumb', 'Inicio'); ?>
<?php $__env->startSection('section-breadcrumb', 'Roles'); ?>
<?php $__env->startSection('module-breadcrumb', 'Configuraciones'); ?>

<?php $__env->startSection('content'); ?>
<div class="card bg-white border-0 shadow-sm border-5 border-top border-secondary">
    <div class="card-body">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger small" role="alert">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('roles.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="row g-3">
                <div class="col-md-6">
                    <label for="name" class="form-label small fw-semibold">Nombre</label>
                    <input type="text" id="name" name="name" value="<?php echo e(old('name')); ?>" class="form-control" required>
                </div>

                <div class="col-md-12">
                    <label for="description" class="form-label small fw-semibold">Descripción</label>
                    <textarea id="description" name="description" class="form-control" rows="4"><?php echo e(old('description')); ?></textarea>
                </div>
            </div>

            <div class="d-flex gap-2 mt-4">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-check-lg me-1"></i>Registrar rol
                </button>
                <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-secondary">Volver</a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.administrador', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Proyecto_Farmacia\sistema\resources\views\settings\roles\create.blade.php ENDPATH**/ ?>