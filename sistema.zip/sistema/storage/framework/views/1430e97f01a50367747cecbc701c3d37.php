<?php $__env->startSection('title', 'CATEGORIAS'); ?>
<?php $__env->startSection('name-section', 'CATEGORIAS'); ?>

<?php $__env->startSection('description', 'Listado de categorías'); ?>
<?php $__env->startSection('item-breadcrumb', 'Inicio'); ?>
<?php $__env->startSection('section-breadcrumb', 'Categorías'); ?>
<?php $__env->startSection('module-breadcrumb', 'Configuraciones'); ?>


<?php $__env->startSection('content'); ?>
<div class="card bg-white border-0 shadow-sm border-5 border-top border-secondary">
                <div class="card-header bg-white">
                    <div class="row">
                        <div class="col-12 col-md-3">
                            <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-primary rounded-3 text-uppercase text-white w-100">
                                <i class="bi bi-plus-lg me-2"></i><span class="small fw-medium">Nuevo registro</span> 
                            </a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <h6 class="text-uppercase small text-muted mb-3">Total de registros encontrados: <?php echo e($categories->count()); ?></h6>
                    <table id="display" class="table table-sm table-hover w-100 bg-white">
                        <thead>
                            <tr>
                                <th class="text-center align-middle text-uppercase small">Nº</th>
                                <th class="text-center align-middle text-uppercase small">Nombre</th>
                                <th class="text-center align-middle text-uppercase small">Descripción</th>
                                <th class="text-center align-middle text-uppercase small">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $contador = 1;
                            ?>
                           <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                                <td class="text-center align-middle"><?php echo e($contador); ?></td>
                                <td class="text-start align-middle"><?php echo e($category->nombre); ?></td>
                                <td class="text-start align-middle"><?php echo e($category->descripcion); ?></td>
                                <td class="text-center align-middle">
                                    <div class="dropdown">
                                        <button class="btn btn-light" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                            <i class="bi bi-three-dots-vertical"></i>
                                        </button>
                                        <ul class="dropdown-menu dropdown-menu-end">
                                            <li><a class="dropdown-item" href="<?php echo e(route('categories.edit' , $category->id)); ?>">Editar</a></li>
                                            <li>
                                                <form action="<?php echo e(route('categories.destroy' , $category->id)); ?>" method="POST" onsubmit="return confirm('¿Estas seguro de eliminar este registro?');">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="dropdown-item">Eliminar</button>
                                                </form>
                                            </li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>
                              <?php
                                $contador++;
                            ?>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.administrador', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Proyecto_Farmacia\sistema\resources\views\settings\categories\roles\index.blade.php ENDPATH**/ ?>