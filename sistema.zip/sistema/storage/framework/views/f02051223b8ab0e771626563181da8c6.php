<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registrar usuario</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/5.1.3/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/2.9.3/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/5.1.3/js/bootstrap.min.js"></script>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f6f9; padding: 30px; }
        .card { border-radius: 10px; }
        .form-label { margin-top: 10px; font-weight: bold; }
        .btn-primary { background: #007bff; border: none; }
        .btn-secondary { background: #6c757d; border: none; }
    </style>
</head>
<body>


<?php $__env->startSection('title', 'USUARIOS'); ?>
<?php $__env->startSection('name-section', 'USUARIOS'); ?>
<?php $__env->startSection('description', 'Registrar nuevo usuario'); ?>
<?php $__env->startSection('item-breadcrumb', 'Inicio'); ?>
<?php $__env->startSection('section-breadcrumb', 'Usuarios'); ?>
<?php $__env->startSection('module-breadcrumb', 'Configuraciones'); ?>

<?php $__env->startSection('content'); ?>
<div class="card bg-white border-0 shadow-sm border-5 border-top border-secondary">
    <div class="card-body">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger small" role="alert">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('users.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label small fw-semibold">Nombre completo</label>
                    <input type="text" name="name" value="<?php echo e(old('name')); ?>" class="form-control" required>
                </div>

                <div class="col-md-3">
                    <label class="form-label small fw-semibold">DNI</label>
                    <input type="text" name="dni" maxlength="8" value="<?php echo e(old('dni')); ?>" class="form-control" required>
                </div>

                <div class="col-md-3">
                    <label class="form-label small fw-semibold">Teléfono</label>
                    <input type="text" name="phone" maxlength="9" value="<?php echo e(old('phone')); ?>" class="form-control" required>
                </div>

                <div class="col-md-4">
                    <label class="form-label small fw-semibold">Matrícula</label>
                    <input type="text" name="tuition" value="<?php echo e(old('tuition')); ?>" class="form-control">
                </div>

                <div class="col-md-4">
                    <label class="form-label small fw-semibold">Correo electrónico</label>
                    <input type="email" name="email" value="<?php echo e(old('email')); ?>" class="form-control" required>
                </div>

                <div class="col-md-4">
                    <label class="form-label small fw-semibold">Contraseña</label>
                    <input type="password" name="password" minlength="8" class="form-control" required>
                </div>

                <div class="col-md-6">
                    <label class="form-label small fw-semibold">Rol</label>
                    <select name="role_id" class="form-select" required>
                        <option value="">Selecciona un rol</option>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($role->id); ?>" <?php if(old('role_id') == $role->id): echo 'selected'; endif; ?>>
                                <?php echo e($role->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="d-flex gap-2 mt-4">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-check-lg me-1"></i>Registrar usuario
                </button>
                <a href="<?php echo e(route('users.index')); ?>" class="btn btn-secondary">Volver</a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
</body>
</html>

<?php echo $__env->make('template.administrador', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Proyecto_Farmacia\sistema\resources\views\users\create.blade.php ENDPATH**/ ?>